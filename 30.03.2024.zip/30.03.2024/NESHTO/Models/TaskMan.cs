﻿using Microsoft.EntityFrameworkCore;

namespace NESHTO.Models
{
    public class TaskMan
    {
        public class TaskManagerContext : DbContext
        {
            public DbSet<Task> Tasks { get; set; }
        }
    }
}
