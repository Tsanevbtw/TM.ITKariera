﻿namespace NESHTO.Models
{
    public class TaskList
    {
        public int Id { get; set; }

        public string? Name { get; set; }
    }
}
