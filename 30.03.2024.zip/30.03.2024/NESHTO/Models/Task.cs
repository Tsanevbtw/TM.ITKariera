﻿namespace NESHTO.Models
{
    public class Task
    {
        public int TaskId { get; set; }
        public string Name { get; set; }
      
        public int ProjectId { get; set; }

        
        public ICollection<Task> Project { get; set; }
    }
}
