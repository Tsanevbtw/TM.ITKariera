﻿using Microsoft.Build.Evaluation;
using Microsoft.EntityFrameworkCore;

namespace NESHTO.Models
{
    public class ToDo
    {
        public int TaskId { get; set; }
        public string Name { get; set; }
        public ICollection<Task> Tasks { get; set; }


    }
}

